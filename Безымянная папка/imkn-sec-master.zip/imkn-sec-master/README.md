﻿# Security
Exercise for Spring Security

Презенитация:

# Начало работы

Для начала работы требуется:

* загрузить репозиторий
* установить JDK 8
* настроить переменную окружения JAVA_HOME указывающую на каталог с JDK 8
* в локальной копии репозитория, в ветке master выполнить
./mvnw clean install (OS X, Linux)
.\mvnw.cmd clean install (MS Windows)
